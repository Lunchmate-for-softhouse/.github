package com.example.lunchmate.model

class User {
}