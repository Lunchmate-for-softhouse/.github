package com.example.lunchmate.viewmodel

class AuthViewModel {
}