package com.example.lunchmate.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.lunchmate.ui.components.CustomButton
import com.example.lunchmate.ui.components.CustomTextField
import com.example.lunchmate.R

@Composable
fun SignInPage(navController: NavController) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0A23)),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.logo),  // Replace with your actual logo resource
            contentDescription = "App Logo",
            modifier = Modifier.size(150.dp),
            contentScale = ContentScale.Fit
        )
        Spacer(modifier = Modifier.height(20.dp))

        CustomTextField(
            value = email,
            onValueChange = { email = it },
            label = "Email"
        )

        CustomTextField(
            value = password,
            onValueChange = { password = it },
            label = "Password",
            isPasswordField = true
        )

        Spacer(modifier = Modifier.height(20.dp))

        CustomButton(
            text = "Sign In",
            onClick = { /* Handle sign in logic */ }
        )

        Spacer(modifier = Modifier.height(10.dp))

        TextButton(onClick = { /* Handle forgot password logic */ }) {
            Text(text = "Forgot password?", color = Color.Gray)
        }

        TextButton(onClick = {navController.navigate("register") }) {
            Text(text = "Don't have an account? Register", color = Color.Gray)
        }
    }
}
