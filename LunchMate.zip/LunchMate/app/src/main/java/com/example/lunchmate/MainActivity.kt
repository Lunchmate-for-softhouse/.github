package com.example.lunchmate

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.lunchmate.ui.screens.HomePage
import com.example.lunchmate.ui.screens.RegisterPage
import com.example.lunchmate.ui.screens.SignInPage
import com.example.lunchmate.ui.theme.LunchMateTheme
import com.example.lunchmate.ui.screens.MapScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LunchMateTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF0A0A23) // Set the default background color for the app
                ) {
                    MainAppNavHost()
                }
            }
        }
    }
}

@Composable
fun MainAppNavHost() {
    val navController: NavHostController = rememberNavController()

    NavHost(navController = navController, startDestination = "home") {
        composable("home") {
            HomePage(navController = navController) // Home screen
        }
        composable("sign_in") {
            SignInPage(navController = navController) // Sign in screen
        }
        composable("register") {
            RegisterPage(navController = navController) // Sign in screen
        }
        composable("map") {
            MapScreen(navController = navController) // Google Map screen
        }
    }
}
