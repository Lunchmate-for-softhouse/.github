package com.example.lunchmate.repository

class AuthRepository {
}